import CafeList from "./components/CafeList";

function App() {
  return (
    <div className="container mx-auto p-5">
      <CafeList />
    </div>
  );
}

export default App;
