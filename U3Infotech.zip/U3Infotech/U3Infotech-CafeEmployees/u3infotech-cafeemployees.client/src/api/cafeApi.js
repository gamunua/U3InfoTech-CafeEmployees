import axios from "axios";

const API_BASE_URL = "http://localhost:5055/";

// Employee APIs
export const getEmployeesByCafe = async (cafeId) => {
  const response = await axios.get(`${API_BASE_URL}/employees`, { params: { cafeId } });
  return response.data;
};

export const updateEmployee = async (id, updatedData) => {
  const response = await axios.put(`${API_BASE_URL}/employees/${id}`, updatedData);
  return response.data;
};

export const deleteEmployee = async (id) => {
  await axios.delete(`${API_BASE_URL}/employees/${id}`);
};

// Cafe APIs
export const getCafesByLocation = async (location) => {
  const response = await axios.get(`${API_BASE_URL}/cafes`, { params: { location } });
  return response.data;
};

export const updateCafe = async (id, updatedData) => {
  const response = await axios.put(`${API_BASE_URL}/cafes/${id}`, updatedData);
  return response.data;
};

export const deleteCafe = async (id) => {
  await axios.delete(`${API_BASE_URL}/cafes/${id}`);
};

export const createEmployee = async (newEmployee) => {
  const response = await axios.post(`${API_BASE_URL}/employees`, newEmployee);
  return response.data;
};

