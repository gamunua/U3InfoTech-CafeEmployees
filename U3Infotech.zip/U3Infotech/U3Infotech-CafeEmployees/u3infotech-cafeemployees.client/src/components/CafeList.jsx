import { useState, useEffect } from "react";
import { getCafesByLocation, updateCafe, deleteCafe } from "../api/cafeApi";

const CafeList = ({ location, onSelectCafe }) => {
  const [cafes, setCafes] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editName, setEditName] = useState("");
  const [editLocation, setEditLocation] = useState("");

  useEffect(() => {
    fetchCafes();
  }, [location]);

  const fetchCafes = async () => {
    const data = await getCafesByLocation(location);
    setCafes(data);
  };

  const handleEditClick = (cafe) => {
    setEditId(cafe.id);
    setEditName(cafe.name);
    setEditLocation(cafe.location);
  };

  const handleSaveEdit = async () => {
    await updateCafe(editId, { id: editId, name: editName, location: editLocation });
    setEditId(null);
    fetchCafes();
  };

  const handleDelete = async (id) => {
    await deleteCafe(id);
    fetchCafes();
  };

  return (
    <div className="mt-4 p-4 border rounded">
      <h3 className="text-xl font-bold">Cafés in {location}</h3>
      <ul>
        {cafes.length > 0 ? (
          cafes.map((cafe) => (
            <li key={cafe.id} className="p-2 border-b flex justify-between items-center">
              {editId === cafe.id ? (
                <div>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="border p-1 rounded"
                  />
                  <input
                    type="text"
                    value={editLocation}
                    onChange={(e) => setEditLocation(e.target.value)}
                    className="border p-1 ml-2 rounded"
                  />
                  <button onClick={handleSaveEdit} className="ml-2 p-1 bg-green-500 text-white rounded">
                    Save
                  </button>
                </div>
              ) : (
                <span onClick={() => onSelectCafe(cafe.id)} className="cursor-pointer">
                  {cafe.name} - {cafe.location}
                </span>
              )}
              <div>
                {editId !== cafe.id && (
                  <button onClick={() => handleEditClick(cafe)} className="mr-2 p-1 bg-blue-500 text-white rounded">
                    Edit
                  </button>
                )}
                <button onClick={() => handleDelete(cafe.id)} className="p-1 bg-red-500 text-white rounded">
                  Delete
                </button>
              </div>
            </li>
          ))
        ) : (
          <p>No cafes found.</p>
        )}
      </ul>
    </div>
  );
};

export default CafeList;
