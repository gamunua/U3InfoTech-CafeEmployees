import { useState, useEffect } from "react";
import { getEmployeesByCafe, updateEmployee, deleteEmployee } from "../api/cafeApi";

const EmployeeList = ({ cafeId }) => {
  const [employees, setEmployees] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editName, setEditName] = useState("");
  const [editPosition, setEditPosition] = useState("");

  useEffect(() => {
    fetchEmployees();
  }, [cafeId]);

  const fetchEmployees = async () => {
    const data = await getEmployeesByCafe(cafeId);
    setEmployees(data);
  };

  const handleEditClick = (employee) => {
    setEditId(employee.id);
    setEditName(employee.name);
    setEditPosition(employee.position);
  };

  const handleSaveEdit = async () => {
    await updateEmployee(editId, { id: editId, name: editName, position: editPosition });
    setEditId(null);
    fetchEmployees();
  };

  const handleDelete = async (id) => {
    await deleteEmployee(id);
    fetchEmployees();
  };

  return (
    <div className="mt-4 p-4 border rounded">
      <h3 className="text-xl font-bold">Employees</h3>
      <ul>
        {employees.length > 0 ? (
          employees.map((emp) => (
            <li key={emp.id} className="p-2 border-b flex justify-between items-center">
              {editId === emp.id ? (
                <div>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="border p-1 rounded"
                  />
                  <input
                    type="text"
                    value={editPosition}
                    onChange={(e) => setEditPosition(e.target.value)}
                    className="border p-1 ml-2 rounded"
                  />
                  <button onClick={handleSaveEdit} className="ml-2 p-1 bg-green-500 text-white rounded">
                    Save
                  </button>
                </div>
              ) : (
                <span>
                  {emp.name} - {emp.position}
                </span>
              )}
              <div>
                {editId !== emp.id && (
                  <button onClick={() => handleEditClick(emp)} className="mr-2 p-1 bg-blue-500 text-white rounded">
                    Edit
                  </button>
                )}
                <button onClick={() => handleDelete(emp.id)} className="p-1 bg-red-500 text-white rounded">
                  Delete
                </button>
              </div>
            </li>
          ))
        ) : (
          <p>No employees found.</p>
        )}
      </ul>
    </div>
  );
};

export default EmployeeList;
