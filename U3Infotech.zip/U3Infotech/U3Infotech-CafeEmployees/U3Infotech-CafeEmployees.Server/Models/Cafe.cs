﻿namespace U3Infotech_CafeEmployees.Server.Models
{
    public class Cafe
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public Int32 Employees { get; set; } = 0;
        
    }

}
