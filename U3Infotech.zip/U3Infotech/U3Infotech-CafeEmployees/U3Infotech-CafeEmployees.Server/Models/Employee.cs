﻿namespace U3Infotech_CafeEmployees.Server.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email_address { get; set; } = string.Empty;
        public string Phone_Number { get; set; } = string.Empty;
        public int Days_worked { get; set; } = 0;
        public int CafeId { get; set; }
        public Cafe? Cafe { get; set; }
    }

}
