﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using U3Infotech_CafeEmployees.Server.Data;
using U3Infotech_CafeEmployees.Server.Models;

public record UpdateEmployeeCommand(int Id,string Name,  string EmailAddress, string PhoneNumber, int DaysWorked) : IRequest<Employee?>;

namespace U3Infotech_CafeEmployees.Server.Features.Employees
{

    public class UpdateEmployeeHandler : IRequestHandler<UpdateEmployeeCommand, Employee?>
    {
        private readonly AppDbContext _context;

        public UpdateEmployeeHandler(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Employee?> Handle(UpdateEmployeeCommand request, CancellationToken cancellationToken)
        {
            var employee = await _context.Employees.FindAsync(request.Id);
            if (employee == null) return null;

            employee.Name = request.Name;
            employee.Email_address = request.EmailAddress;
            employee.Phone_Number = request.PhoneNumber;
            employee.Days_worked = request.DaysWorked;

            await _context.SaveChangesAsync();
            return employee;
        }
    }

}
