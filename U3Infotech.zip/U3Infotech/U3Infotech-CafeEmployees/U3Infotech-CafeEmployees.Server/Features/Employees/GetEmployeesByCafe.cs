﻿
using MediatR;
using Microsoft.EntityFrameworkCore;
using U3Infotech_CafeEmployees.Server.Data;
using U3Infotech_CafeEmployees.Server.Models;

public record GetEmployeesByCafeQuery(int CafeId) : IRequest<List<Employee>>;

namespace U3Infotech_CafeEmployees.Server.Features.Employees
{
    public class GetEmployeesByCafeHandler : IRequestHandler<GetEmployeesByCafeQuery, List<Employee>>
    {
        private readonly AppDbContext _context;

        public GetEmployeesByCafeHandler(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Employee>> Handle(GetEmployeesByCafeQuery request, CancellationToken cancellationToken)
        {
            return await _context.Employees
                .Where(e => e.CafeId == request.CafeId)
                .ToListAsync();
        }
    }

}
