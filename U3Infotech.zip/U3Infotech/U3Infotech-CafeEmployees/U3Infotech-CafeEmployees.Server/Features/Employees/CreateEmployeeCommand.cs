﻿using MediatR;
using U3Infotech_CafeEmployees.Server.Models;
using U3Infotech_CafeEmployees.Server.Data;

public record CreateEmployeeCommand(string Name, string EmailAddress,string PhoneNumber,int  DaysWorked, int CafeId) : IRequest<Employee>;


namespace U3Infotech_CafeEmployees.Server.Features.Employees
{

    public class CreateEmployeeHandler : IRequestHandler<CreateEmployeeCommand, Employee>
    {
        private readonly AppDbContext _context;

        public CreateEmployeeHandler(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Employee> Handle(CreateEmployeeCommand request, CancellationToken cancellationToken)
        {
            var employee = new Employee
            {
                Name = request.Name,
                Email_address = request.EmailAddress,
                Phone_Number = request.PhoneNumber,
                Days_worked = request.DaysWorked,
                CafeId = request.CafeId
            };

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();
            return employee;
        }
    }
}
