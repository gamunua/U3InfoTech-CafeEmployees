﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using U3Infotech_CafeEmployees.Server.Data;
using U3Infotech_CafeEmployees.Server.Models;


public record GetCafesByLocationQuery(string Location) : IRequest<List<Cafe>>;


namespace U3Infotech_CafeEmployees.Server.Features.Cafes
{
    public class GetCafesByLocationHandler : IRequestHandler<GetCafesByLocationQuery, List<Cafe>>
    {
        private readonly AppDbContext _context;

        public GetCafesByLocationHandler(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Cafe>> Handle(GetCafesByLocationQuery request, CancellationToken cancellationToken)
        {
            return await _context.Cafes
                .Where(c => c.Location.ToLower() == request.Location.ToLower())
                .ToListAsync();
        }
    }

}
