﻿
using MediatR;
using Microsoft.EntityFrameworkCore;
using U3Infotech_CafeEmployees.Server.Models;
using U3Infotech_CafeEmployees.Server.Data;

public record UpdateCafeCommand(int Id, string Name, string Location,string Description,int NumOfEmployees) : IRequest<Cafe?>;

namespace U3Infotech_CafeEmployees.Server.Features.Cafes
{
    public class UpdateCafeHandler : IRequestHandler<UpdateCafeCommand, Cafe?>
    {
        private readonly AppDbContext _context;

        public UpdateCafeHandler(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Cafe?> Handle(UpdateCafeCommand request, CancellationToken cancellationToken)
        {
            var cafe = await _context.Cafes.FindAsync(request.Id);
            if (cafe == null) return null;

            cafe.Name = request.Name;
            cafe.Location = request.Location;
            cafe.Description = request.Description;
            cafe.Employees = request.NumOfEmployees;

            await _context.SaveChangesAsync();
            return cafe;
        }
    }

}
