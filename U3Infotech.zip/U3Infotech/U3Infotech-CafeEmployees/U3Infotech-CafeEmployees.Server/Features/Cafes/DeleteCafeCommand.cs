﻿using MediatR;
using U3Infotech_CafeEmployees.Server.Models;
using U3Infotech_CafeEmployees.Server.Data;

public record DeleteCafeCommand(int Id) : IRequest<bool>;

namespace U3Infotech_CafeEmployees.Server.Features.Cafes
{
    public class DeleteCafeHandler : IRequestHandler<DeleteCafeCommand, bool>
    {
        private readonly AppDbContext _context;

        public DeleteCafeHandler(AppDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteCafeCommand request, CancellationToken cancellationToken)
        {
            var cafe = await _context.Cafes.FindAsync(request.Id);
            if (cafe == null) return false;

            _context.Cafes.Remove(cafe);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
