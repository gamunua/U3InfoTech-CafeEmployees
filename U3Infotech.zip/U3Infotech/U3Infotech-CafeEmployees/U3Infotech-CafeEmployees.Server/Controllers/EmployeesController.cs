﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using U3Infotech_CafeEmployees.Server.Features.Cafes;
using U3Infotech_CafeEmployees.Server.Models;


namespace U3Infotech_CafeEmployees.Server.Controllers
{

    [ApiController]
    [Route("api/employees")]
    public class EmployeesController : ControllerBase
    {
        private readonly IMediator _mediator;

        public EmployeesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> GetEmployeesByCafe([FromQuery] int cafeId)
        {
            var employees = await _mediator.Send(new GetEmployeesByCafeQuery(cafeId));
            return Ok(employees);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEmployee(int id, [FromBody] UpdateEmployeeCommand command)
        {
            if (id != command.Id)
                return BadRequest("ID mismatch");

            var updatedEmployee = await _mediator.Send(command);
            return updatedEmployee != null ? Ok(updatedEmployee) : NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var result = await _mediator.Send(new DeleteEmployeeCommand(id));
            return result ? NoContent() : NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> CreateEmployee([FromBody] CreateEmployeeCommand command)
        {
            var newEmployee = await _mediator.Send(command);
            return CreatedAtAction(nameof(GetEmployeesByCafe), new { cafeId = newEmployee.CafeId }, newEmployee);
        }

    }
}
