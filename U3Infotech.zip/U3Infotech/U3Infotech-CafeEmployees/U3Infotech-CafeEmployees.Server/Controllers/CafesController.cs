﻿
using MediatR;
using Microsoft.AspNetCore.Mvc;
using U3Infotech_CafeEmployees.Server.Features.Cafes;
using U3Infotech_CafeEmployees.Server.Models;
namespace U3Infotech_CafeEmployees.Server.Controllers
{
    [ApiController]
    [Route("api/cafes")]
    public class CafesController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CafesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> GetCafesByLocation([FromQuery] string location)
        {
            var cafes = await _mediator.Send(new GetCafesByLocationQuery(location));
            return Ok(cafes);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCafe(int id, [FromBody] UpdateCafeCommand command)
        {
            if (id != command.Id)
                return BadRequest("ID mismatch");

            var updatedCafe = await _mediator.Send(command);
            return updatedCafe != null ? Ok(updatedCafe) : NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCafe(int id)
        {
            var result = await _mediator.Send(new DeleteCafeCommand(id));
            return result ? NoContent() : NotFound();
        }
    }
}


