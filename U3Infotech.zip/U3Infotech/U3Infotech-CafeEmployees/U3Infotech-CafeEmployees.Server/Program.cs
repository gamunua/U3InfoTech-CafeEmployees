using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;
using U3Infotech_CafeEmployees.Server.Data;
using U3Infotech_CafeEmployees.Server.Features.Cafes;
using U3Infotech_CafeEmployees.Server.Features.Employees;
using U3Infotech_CafeEmployees.Server.Models;



var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddDbContext<AppDbContext>(opt => opt.UseInMemoryDatabase("CafeDb"));
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly()));


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Seed some data for cafe and employees
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Cafes.AddRange(
        new Cafe { Name = "Infotech Hub ", Location = "New York",Id =1,Employees=50 ,Description = "Infotech Cafe" },
        new Cafe { Name = "Java Cafe", Location = "New York", Id = 2,Employees=100,Description = "Java hub" },
        new Cafe { Name = "Barista", Location = "Los Angeles", Id = 3 ,Employees=60,Description = "Barista Hub" }
    );
    db.Employees.AddRange(
        new Employee { Name = "Gamunu", Email_address = "Gamunu@test.com", CafeId = 1,Days_worked =4,Phone_Number="087744444"},
        new Employee { Name = "Bob", Email_address = "bob@gmail.com", CafeId = 1 ,Days_worked =6, Phone_Number = "123455677" },
        new Employee { Name = "Shantha", Email_address = "Shantha@gmail.com", CafeId = 2,Days_worked=90, Phone_Number = "657899999" }
    );
    db.SaveChanges();
}


app.UseDefaultFiles();
app.UseStaticFiles();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.MapFallbackToFile("/index.html");

app.Run();
