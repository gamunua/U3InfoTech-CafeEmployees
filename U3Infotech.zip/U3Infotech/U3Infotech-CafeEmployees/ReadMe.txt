Run Commands



API  Project 

U3Infotech-CafeEmployees.Server 

Server Url

http://localhost:5055/

Client 

u3infotech-cafeemployees.client

Used Vite build tool 

Command

npm run dev